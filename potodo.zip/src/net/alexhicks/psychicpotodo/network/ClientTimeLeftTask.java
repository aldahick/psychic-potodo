package net.alexhicks.psychicpotodo.network;

import java.util.TimerTask;

public class ClientTimeLeftTask extends TimerTask {

	@Override
	public void run() {
		
	}

}
