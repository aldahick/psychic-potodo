package net.alexhicks.psychicpotodo.network;

import java.util.TimerTask;

public class ServerClearTask extends TimerTask {
	
	private NetworkServer server;
	
	public ServerClearTask(NetworkServer server) {
		this.server = server;
	}
	
	@Override
	public void run() {
		this.server.lastClearTime = System.currentTimeMillis();
		this.server.history.clear();
		// clients should clear automatically since they know the last time it happened
	}
}
