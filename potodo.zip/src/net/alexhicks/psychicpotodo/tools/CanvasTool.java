package net.alexhicks.psychicpotodo.tools;

public interface CanvasTool {
	
}
